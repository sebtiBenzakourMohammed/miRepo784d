<?php
/**
 * @package Dotclear
 * @subpackage Plugins
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */

if (!isset($__resources['help']['blogroll'])) {
    $__resources['help']['blogroll'] = dirname(__FILE__) . '/help/blogroll.html';
}
