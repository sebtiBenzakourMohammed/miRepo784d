<?php
/**
 * @package Dotclear
 * @subpackage Plugins
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */

if (!isset($__resources['help']['userPref'])) {
    $__resources['help']['userPref'] = dirname(__FILE__) . '/help/help.html';
}
