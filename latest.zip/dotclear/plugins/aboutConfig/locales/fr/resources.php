<?php
/**
 * @package Dotclear
 * @subpackage Plugins
 *
 * @copyright Olivier Meunier & Association Dotclear
 * @copyright GPL-2.0-only
 */

if (!isset($__resources['help']['aboutConfig'])) {
    $__resources['help']['aboutConfig'] = dirname(__FILE__) . '/help/help.html';
}
